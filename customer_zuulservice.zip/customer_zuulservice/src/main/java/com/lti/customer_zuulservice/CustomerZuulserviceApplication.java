package com.lti.customer_zuulservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@EnableDiscoveryClient


@SpringBootApplication
public class CustomerZuulserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerZuulserviceApplication.class, args);
	}

}
