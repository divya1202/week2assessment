package com.lti.customer_zuulservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerZuulserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
